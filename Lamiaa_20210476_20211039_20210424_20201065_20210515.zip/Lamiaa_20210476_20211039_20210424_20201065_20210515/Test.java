/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package invertedIndex;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author ehab
 */

public class Test {


    public static void main(String args[]) throws IOException {
        Index5 index = new Index5();
        String files = "D:/Yousef/IR/Assignments/ASs2/Lamiaa_20210476_20211039_20210424_20201065_20210515/tmp11/rl/collection/";

        File file = new File(files);
        String[] fileList = file.list();

        fileList = index.sort(fileList);
        index.N = fileList.length;

        for (int i = 0; i < fileList.length; i++) {
            fileList[i] = files + fileList[i];
        }
        index.buildIndex(fileList);
        index.buildBiwordIndex(fileList);
        index.store("index");
        index.printDictionary();
        index.printBiwordIndex();

        String phrase = "";
        do {
            System.out.println("Print search phrase: ");
            BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
            phrase = in.readLine();

            if (!phrase.isEmpty()) {
                System.out.println("Choose search type: 1 for simple inverted index, 2 for positional index, 3 for biword index, 4 mix single word with phrase");
                String searchType = in.readLine();

                if ("1".equals(searchType)) {
                    System.out.println("Search result: \n" + index.find_24_inverted(phrase));
                } else if ("2".equals(searchType)) {
                    System.out.println("Search result: \n" + index.find_24_positional(phrase));
                }
                else if ("3".equals(searchType)) {
                    System.out.println("Search result: \n" + index.find_24_BIWord(phrase));
                }
            else if ("4".equals(searchType)) {
                System.out.println("Search result: \n" + index.find_24_mix(phrase));
            }
                else {
                    System.out.println("Invalid search type. Please enter number in range [1-4].");
                }
            }
        } while (!phrase.isEmpty());
    }


}
